//
//  Student.h
//  SQLite
//
//  Created by pcs20 on 9/22/14.
//  Copyright (c) 2014 Paradigmcreatives. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject

@property(nonatomic,strong)NSString *studentName;
@property(nonatomic,strong)NSString *studentID;
@property(nonatomic,strong)NSString *studentDepartment;
@property(nonatomic,strong)NSString *studentAge;




@end
